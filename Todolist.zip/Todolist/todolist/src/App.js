import Todolist from "./components/Todolist";
import "./App.css";

export default function App() {
  return (
    <div className="App">
      <Todolist/>
    </div>
  );
}
